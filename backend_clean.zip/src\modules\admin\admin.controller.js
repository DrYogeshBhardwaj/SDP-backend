const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { successResponse, errorResponse } = require('../../utils/response');

/**
 * V1 Admin Controller (Rebirth)
 */

const getStats = async (req, res) => {
    try {
        const totalUsers = await prisma.user.count();
        const activeUsers = await prisma.user.count({ where: { status: 'ACTIVE' } });
        
        // Wholesale Metrics
        const today = new Date();
        today.setHours(0,0,0,0);

        // 1. Total In (Revenue)
        const revenueAgg = await prisma.transaction.aggregate({
            where: { category: 'REGISTRATION_FEE' },
            _sum: { amount: true }
        });
        const totalIn = revenueAgg._sum.amount || 0;

        // 2. Today's In
        const todayReceipts = await prisma.transaction.findMany({
            where: { 
                category: 'REGISTRATION_FEE',
                createdAt: { gte: today }
            }
        });
        const todayIn = todayReceipts.reduce((acc, r) => acc + r.amount, 0);

        // 3. Total Out (Paid Payouts)
        const paidAgg = await prisma.payout.aggregate({
            where: { status: 'PAID' },
            _sum: { amount: true }
        });
        const totalOut = paidAgg._sum.amount || 0;

        // 4. Total Liability (Current Wallets)
        const wallets = await prisma.wallet.findMany({ where: { type: 'CASH' } });
        const totalLiability = wallets.reduce((acc, w) => acc + w.balance, 0);

        // 5. System Alerts (Gadbad Detection)
        const alerts = [];
        const negativeWallets = wallets.filter(w => w.balance < 0);
        if (negativeWallets.length > 0) {
            alerts.push({
                type: 'CRITICAL',
                message: `${negativeWallets.length} users have negative balances (ILLegal).`
            });
        }

        // Quick Audit: Total In SHOULD be >= Total Out + Total Liability
        // (Revenue >= Paid + Owed)
        if (totalIn < (totalOut + totalLiability)) {
            alerts.push({
                type: 'WARNING',
                message: `Audit Mismatch: Distributed commissions (${totalOut + totalLiability} exceeds Total Revenue (${totalIn}).`
            });
        }

        const recentTransactions = await prisma.transaction.count({
            where: { createdAt: { gte: today } }
        });

        return successResponse(res, 200, 'Admin Stats', {
            wholesale: {
                totalUsers,
                activeUsers,
                totalIn,
                todayIn,
                totalOut,
                totalLiability,
                recentTransactions,
                alerts
            }
        });
    } catch (err) {
        console.error('[ADMIN_STATS_ERROR]', err);
        return errorResponse(res, 500, 'Failed to fetch stats');
    }
};

const getPendingBalances = async (req, res) => {
    try {
        const pending = await prisma.wallet.findMany({
            where: { 
                type: 'CASH',
                balance: { gt: 0 }
            },
            include: { user: { select: { id: true, mobile: true, name: true, upiId: true } } },
            orderBy: { balance: 'desc' }
        });
        return successResponse(res, 200, 'Pending Balances', pending);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch pending balances');
    }
};

const getAllUsers = async (req, res) => {
    try {
        const users = await prisma.user.findMany({
            include: { wallets: true },
            orderBy: { createdAt: 'desc' }
        });
        return successResponse(res, 200, 'User List', users);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch users');
    }
};

const getPayouts = async (req, res) => {
    try {
        const payouts = await prisma.payout.findMany({
            include: { user: { select: { mobile: true, name: true, upiId: true } } },
            orderBy: { createdAt: 'desc' }
        });
        return successResponse(res, 200, 'Payout List', payouts);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch payouts');
    }
};

const processPayout = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, transactionId } = req.body;

        const updated = await prisma.payout.update({
            where: { id },
            data: { 
                status, 
                transactionId,
                processedAt: status === 'PAID' ? new Date() : undefined
            }
        });

        return successResponse(res, 200, `Payout marked as ${status}`, updated);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to process payout');
    }
};

const getQueries = async (req, res) => {
    try {
        const queries = await prisma.supportQuery.findMany({
            include: { user: { select: { mobile: true } } },
            orderBy: { createdAt: 'desc' }
        });
        return successResponse(res, 200, 'Query List', queries);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch queries');
    }
};

const getCashLogs = async (req, res) => {
    try {
        const logs = await prisma.transaction.findMany({
            take: 100,
            orderBy: { createdAt: 'desc' },
            include: { user: { select: { mobile: true } } }
        });
        return successResponse(res, 200, 'Cash Logs', logs);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch logs');
    }
};

const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, name, minutesBalance, role, upiId } = req.body;

        console.log(`[ADMIN_UPDATE] Updating user ${id}:`, { name, status, role, minutesBalance, upiId });

        const updated = await prisma.user.update({
            where: { id },
            data: { 
                status, 
                name, 
                minutesBalance: parseInt(minutesBalance) || 0, 
                role,
                upiId
            }
        });

        return successResponse(res, 200, 'User updated', updated);
    } catch (err) {
        console.error('[ADMIN_UPDATE_ERROR]', err);
        return errorResponse(res, 500, 'Update failed');
    }
};

const updateQuery = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, response } = req.body;

        const updated = await prisma.supportQuery.update({
            where: { id },
            data: { status, response }
        });

        return successResponse(res, 200, 'Query updated', updated);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to update query');
    }
};

const sweepToPayouts = async (req, res) => {
    try {
        // 1. Find users with CASH balance > 0 and UPI ID set
        const wallets = await prisma.wallet.findMany({
            where: {
                type: 'CASH',
                balance: { gt: 0 },
                user: { upiId: { not: null, not: '' } }
            },
            include: { user: { select: { id: true, mobile: true } } }
        });

        if (wallets.length === 0) {
            return successResponse(res, 200, 'No eligible balances to sweep.');
        }

        let processedCount = 0;
        let totalAmount = 0;

        // 2. Process each wallet (Sequential for safety, could be bulked later)
        for (const wallet of wallets) {
            const amount = wallet.balance;
            const userId = wallet.user.id;

            await prisma.$transaction([
                prisma.wallet.update({
                    where: { id: wallet.id },
                    data: { balance: 0 } // Sweep full balance
                }),
                prisma.payout.create({
                    data: {
                        userId,
                        amount,
                        status: 'PENDING'
                    }
                }),
                prisma.transaction.create({
                    data: {
                        userId,
                        amount,
                        type: 'DEBIT',
                        category: 'PAYOUT_REQUEST',
                        description: `Auto-Sweep: Full balance payout ₹${amount}`
                    }
                })
            ]);
            processedCount++;
            totalAmount += amount;
        }

        return successResponse(res, 201, `Successfully swept ₹${totalAmount} from ${processedCount} users into Payout records.`);
    } catch (err) {
        console.error('[SWEEP_ERROR]', err);
        return errorResponse(res, 500, 'Failed to sweep balances');
    }
};

const getNetworkTree = async (req, res) => {
    try {
        const users = await prisma.user.findMany({
            select: { 
                id: true, 
                mobile: true, 
                name: true, 
                sponsorId: true,
                role: true,
                createdAt: true
            }
        });
        return successResponse(res, 200, 'Network Tree Data', users);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch network tree');
    }
};

module.exports = { 
    getStats, 
    getAllUsers, 
    getCashLogs, 
    updateUser, 
    getPayouts, 
    processPayout, 
    getQueries, 
    updateQuery,
    getPendingBalances,
    sweepToPayouts,
    getNetworkTree
};
