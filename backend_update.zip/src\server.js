require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
    origin: [
        'http://localhost:5000', 
        'https://aura.sinaank.com', 
        'http://aura.sinaank.com',
        'https://sinaank.com',
        'http://sinaank.com',
        'https://www.sinaank.com',
        'http://www.sinaank.com'
    ],
    credentials: true
}));
app.use(express.json());

// Routes
app.use('/api', require('./routes/auth.routes'));
app.use('/api/payment', require('./routes/payment.routes'));
app.use('/api/therapy', require('./routes/therapy.routes'));
app.use('/api/admin', require('./routes/admin.routes'));
app.use('/api/user', require('./routes/user.routes'));

// Serve Frontend
app.use(express.static(path.join(__dirname, '../../frontend')));

// Health Check
app.get('/health', (req, res) => res.json({ status: 'Sinaank V1 Active' }));

// Final fallback - SPA support
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../../frontend/index.html'));
});

// JSON Error Middleware - ENSURE ALL ERRORS ARE JSON
app.use((err, req, res, next) => {
    console.error('[GLOBAL_ERROR]', err);
    res.status(err.status || 500).json({
        success: false,
        message: err.message || 'Internal Server Error'
    });
});

app.listen(PORT, () => {
    console.log(`\x1b[32m[SINAANK V1]\x1b[0m Server running on http://localhost:${PORT}`);
});
